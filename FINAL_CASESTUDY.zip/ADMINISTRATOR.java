package FINAL_CASESTUDY;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EtchedBorder;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class ADMINISTRATOR extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private static final DecimalFormat df = new DecimalFormat("0.00");
	private JTextField txtpinnum, txtaccnum, txtaccname, txtcurrbal, txtdob, txtgender, txtcs;
	private JButton btnShow, btnSearch, btnNew, btnSave, btnDelete, btnUpdate, btnCancel, btnQuit,btnClear;
	static String Pin_Number, Account_Number, Account_Name, Current_Balance, Date_of_Birth, Gender, Civil_Status;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String query;
	private JPanel panel;
	static String pinnum;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTable table;
	private DefaultTableModel model;
	private JScrollPane pane;
	private JTextField txtQuery;
	private Object[] row = new Object[7];
	private JLabel icon_2;
	private JLabel lblMarvelAvengersBanking;
	private JLabel icon_3;
	private JLabel lblMarvelAvengers;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADMINISTRATOR ad = new ADMINISTRATOR();
					ad.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void dbconnect()	{
	try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_information","root","");
		stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);	
	}
	catch(Exception e)	{
		e.printStackTrace();
	}
	}
	public void show1() throws SQLException	{
		while(rs.next())	{
			row[0] = rs.getInt("Pin_Number");
			row[1] = rs.getString("Account_Number");
			row[2] = rs.getString("Account_Name");
			row[3] = (df.format(rs.getFloat("Current_Balance")));
			row[4] = rs.getDate("Date_of_Birth");
			row[5] = rs.getString("Gender");
			row[6] = rs.getString("Civil_Status");
			model.addRow(row);
		}
	}
	public void displayValues() throws SQLException	{
		txtpinnum.setText(rs.getString("Pin_Number"));
		txtaccnum.setText(rs.getString("Account_Number"));
		txtaccname.setText(rs.getString("Account_Name"));
		txtcurrbal.setText(String.valueOf(df.format(rs.getFloat("Current_Balance"))));
		txtdob.setText(rs.getString("Date_of_Birth"));
		txtgender.setText(rs.getString("Gender"));
		txtcs.setText(rs.getString("Civil_Status"));
	}
	/**
	 * Create the application.
	 */
	public ADMINISTRATOR() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("ATM_ICON.png")));
		getContentPane().setBackground(Color.BLACK);
		initialize();
		dbconnect();
		try	{
			query = "select * from customer_informationtb";
			rs = stmt.executeQuery(query);
			rs.first();
			displayValues();
			
		}	catch(SQLException e1)	{
			e1.printStackTrace();
		}
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		UIManager.put("OptionPane.background", Color.white);
		UIManager.put("Panel.background", Color.white);
		table = new JTable();
		table.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		Object[] columns = {"Pin Number","Account Number","Account Name","Current Balance","Date of Birth","Gender","Civil Status"};
		
		model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);
		table.setModel(model);
		
		table.setBackground(Color.white);
		table.setForeground(Color.black);
		table.setSelectionBackground(Color.BLACK);
		table.setGridColor(Color.BLACK);
		table.setSelectionBackground(Color.white);
		table.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		table.setRowHeight(30);
		table.setAutoCreateRowSorter(true);
		table.setVisible(true);
		
		pane = new JScrollPane(table);
		pane.setForeground(Color.RED);
		pane.setBackground(Color.WHITE);
		pane.setBounds(10,215,991,204);
		getContentPane().add(pane);
		
		setTitle("I-AINS GROUP 01 ADMINISTRATOR");
		setBounds(100, 100, 1027, 469);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
	
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setForeground(Color.GRAY);
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 991, 204);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		btnSearch = new JButton("SEARCH");
		btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		btnSearch.setForeground(Color.WHITE);
		btnSearch.setBackground(Color.DARK_GRAY);
		btnSearch.setBounds(424, 77, 137, 31);
		panel.add(btnSearch);
		
		btnDelete = new JButton("DELETE");
		btnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnDelete.setBackground(Color.DARK_GRAY);
		btnDelete.setForeground(Color.WHITE);
		btnDelete.setBounds(826, 77, 137, 31);
		panel.add(btnDelete);
		
		btnUpdate = new JButton("UPDATE");
		btnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnUpdate.setBackground(Color.LIGHT_GRAY);
		btnUpdate.setBounds(625, 77, 137, 31);
		panel.add(btnUpdate);
		
		btnSave = new JButton("SAVE");
		btnSave.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnSave.setBackground(Color.LIGHT_GRAY);
		btnSave.setBounds(223, 77, 137, 31);
		panel.add(btnSave);
		
		btnNew = new JButton("NEW");
		btnNew.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnNew.setForeground(Color.WHITE);
		btnNew.setBackground(Color.DARK_GRAY);
		btnNew.setBounds(29, 77, 137, 31);
		panel.add(btnNew);
		
		txtpinnum = new JTextField();
		txtpinnum.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtpinnum.setBounds(29, 26, 92, 30);
		panel.add(txtpinnum);
		txtpinnum.setText((String)null);
		txtpinnum.setColumns(10);
		
		txtaccnum = new JTextField();
		txtaccnum.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtaccnum.setBounds(156, 26, 102, 30);
		panel.add(txtaccnum);
		txtaccnum.setText((String)null);
		txtaccnum.setColumns(10);
		
		txtaccname = new JTextField();
		txtaccname.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtaccname.setBounds(298, 26, 202, 30);
		panel.add(txtaccname);
		txtaccname.setText((String)null);
		txtaccname.setColumns(10);
		
		txtcurrbal = new JTextField();
		txtcurrbal.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtcurrbal.setBounds(536, 26, 104, 30);
		panel.add(txtcurrbal);
		txtcurrbal.setText((String)null);
		txtcurrbal.setColumns(10);
		
		txtdob = new JTextField();
		txtdob.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtdob.setBounds(674, 26, 104, 30);
		panel.add(txtdob);
		txtdob.setText((String)null);
		txtdob.setColumns(10);
		
		txtgender = new JTextField();
		txtgender.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtgender.setBounds(808, 26, 68, 30);
		panel.add(txtgender);
		txtgender.setText((String)null);
		txtgender.setColumns(10);
		
		txtcs = new JTextField();
		txtcs.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtcs.setBounds(895, 26, 68, 30);
		panel.add(txtcs);
		txtcs.setText((String)null);
		txtcs.setColumns(10);
		
		JLabel lblnewLabel = new JLabel("Pin Number");
		lblnewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblnewLabel.setForeground(Color.WHITE);
		lblnewLabel.setBounds(29, 10, 92, 14);
		panel.add(lblnewLabel);
		
		JLabel lblnewLabel_1 = new JLabel("Account Name");
		lblnewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblnewLabel_1.setForeground(Color.WHITE);
		lblnewLabel_1.setBounds(298, 10, 202, 14);
		panel.add(lblnewLabel_1);
		
		JLabel lblnewLabel_2 = new JLabel("Current Balance");
		lblnewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblnewLabel_2.setForeground(Color.WHITE);
		lblnewLabel_2.setBounds(536, 10, 104, 14);
		panel.add(lblnewLabel_2);
		
		JLabel lblnewLabel_3 = new JLabel("Date of Birth");
		lblnewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblnewLabel_3.setForeground(Color.WHITE);
		lblnewLabel_3.setBounds(674, 10, 104, 14);
		panel.add(lblnewLabel_3);
		
		txtQuery = new JTextField();
		txtQuery.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtQuery.setHorizontalAlignment(SwingConstants.CENTER);
		txtQuery.setBounds(223, 173, 537, 20);
		panel.add(txtQuery);
		txtQuery.setColumns(10);
		
		btnShow = new JButton("SHOW RECORDS");
		btnShow.setForeground(Color.WHITE);
		btnShow.setBackground(new Color(220, 20, 60));
		btnShow.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_information","root","");
					stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					row[0] = "";
					row[1] = "";
					row[2] = "";
					row[3] = "";
					row[4] = "";
					row[5] = "";
					row[6] = "";
					model.addRow(row);
					while(model.getRowCount() > 0)	{
						model.removeRow(0);
					}
					if(txtQuery.getText().equals(""))	{
						rs = stmt.executeQuery("select * from customer_informationtb");
						show1();
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Pin_Number from customer_informationtb")){
						rs = stmt.executeQuery("select Pin_Number from customer_informationtb");
						while(rs.next())	{
							row[0] = rs.getInt("Pin_Number");
						model.addRow(row);
						}
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Account_Number from customer_informationtb")){
						rs = stmt.executeQuery("select Account_Number from customer_informationtb");
						while(rs.next())	{
							row[1] = rs.getInt("Account_Number");
						model.addRow(row);
						}
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Account_Name from customer_informationtb")){
						rs = stmt.executeQuery( "select Account_Name from customer_informationtb");
						while(rs.next())	{
							row[2] = rs.getString("Account_Name");
						model.addRow(row);
						}
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Current_Balance from customer_informationtb")){
						rs = stmt.executeQuery("select Current_Balance from customer_informationtb");
						while(rs.next())	{
							row[3] = (df.format(rs.getFloat("Current_Balance")));
						model.addRow(row);
						}
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Date_of_Birth from customer_informationtb")){
						rs = stmt.executeQuery("select Date_of_Birth from customer_informationtb");
						while(rs.next())	{
							row[4] = rs.getDate("Date_of_Birth");
						model.addRow(row);
						}
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Gender from customer_informationtb")){
						rs = stmt.executeQuery( "select Gender from customer_informationtb");
						while(rs.next())	{
							row[5] = rs.getString("Gender");
						model.addRow(row);
						}
					}
					else if(txtQuery.getText().equalsIgnoreCase("select Civil_Status from customer_informationtb")){
						rs = stmt.executeQuery("select Civil_Status from customer_informationtb");
						while(rs.next())	{
							row[6] = rs.getString("Civil_Status");
						model.addRow(row);
						}
					}
					else {
						query = txtQuery.getText();
						rs = stmt.executeQuery(query);
						show1();
					}
				}
				catch(Exception e1)	{
					JOptionPane.showMessageDialog(null, "INVALID SQL COMMAND","ERROR", JOptionPane.WARNING_MESSAGE);
					//e1.printStackTrace();
				}			
			}
		});
		btnShow.setBounds(223, 128, 447, 42);
		panel.add(btnShow);
		
		JLabel lblNewLabel = new JLabel("Account Number");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(156, 10, 102, 14);
		panel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Gender");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(808, 10, 68, 14);
		panel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Civil Status");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(895, 10, 68, 14);
		panel.add(lblNewLabel_2);
		
		btnCancel = new JButton("CANCEL");
		btnCancel.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnCancel.setForeground(Color.WHITE);
		btnCancel.setBackground(new Color(0, 0, 205));
		btnCancel.setBounds(29, 138, 89, 23);
		panel.add(btnCancel);
		
		btnQuit = new JButton("QUIT");
		btnQuit.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnQuit.setForeground(Color.WHITE);
		btnQuit.setBackground(new Color(255, 0, 0));
		btnQuit.setBounds(874, 138, 89, 23);
		panel.add(btnQuit);
		
		btnClear = new JButton("CLEAR");
		btnClear.setForeground(Color.WHITE);
		btnClear.setBackground(new Color(6,57,112));
		btnClear.setBounds(671, 128, 89, 42);
		panel.add(btnClear);
		
		icon_2 = new JLabel("MABC");
		icon_2.setForeground(Color.WHITE);
		icon_2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 35));
		icon_2.setBounds(760, 105, 137, 35);
		panel.add(icon_2);
		
		lblMarvelAvengersBanking = new JLabel("BANKING CORPORATION");
		lblMarvelAvengersBanking.setForeground(Color.WHITE);
		lblMarvelAvengersBanking.setFont(new Font("Eras Light ITC", Font.BOLD, 12));
		lblMarvelAvengersBanking.setBounds(796, 162, 148, 20);
		panel.add(lblMarvelAvengersBanking);
		
		lblMarvelAvengers = new JLabel("MARVEL AVENGERS");
		lblMarvelAvengers.setForeground(Color.WHITE);
		lblMarvelAvengers.setFont(new Font("Eras Light ITC", Font.BOLD, 12));
		lblMarvelAvengers.setBounds(760, 150, 114, 20);
		panel.add(lblMarvelAvengers);
		
		JLabel icon = new JLabel("");
		icon.setBackground(Color.BLACK);
		icon.setFont(new Font("ZWAdobeF", Font.PLAIN, 5));
		icon.setForeground(new Color(0.0f, 0.0f, 0.0f, 0.5f));
		icon.setIcon(new ImageIcon(this.getClass().getResource("BG_WITHDRAW_DEPOSIT.png")));
		icon.setBounds(0, 0, 428, 204);
		panel.add(icon);
		
		JLabel icon_1 = new JLabel("");
		icon_1.setIcon(new ImageIcon(this.getClass().getResource("BG_NOVA.jpg")));
		icon_1.setForeground(new Color(0, 0, 0, 128));
		icon_1.setFont(new Font("Dialog", Font.PLAIN, 5));
		icon_1.setBackground(Color.BLACK);
		icon_1.setBounds(393, -12, 331, 183);
		panel.add(icon_1);
		
		icon_3 = new JLabel("");
		icon_3.setIcon(new ImageIcon(this.getClass().getResource("BG_EARTH.jpg")));
		icon_3.setForeground(new Color(0, 0, 0, 128));
		icon_3.setFont(new Font("Dialog", Font.PLAIN, 5));
		icon_3.setBackground(Color.BLACK);
		icon_3.setBounds(818, 45, 173, 159);
		panel.add(icon_3);
		
		btnNew.addActionListener(this);
		btnSave.addActionListener(this);
		btnUpdate.addActionListener(this);
		btnDelete.addActionListener(this);
		btnSearch.addActionListener(this);
		btnCancel.addActionListener(this);
		btnQuit.addActionListener(this);
		btnClear.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)	{
		
		if(e.getSource() == btnClear)	{
			try {
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_information","root","");
				stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				while(model.getRowCount() > 0)	{
					model.removeRow(0);
				}
				while(rs.next())	{
					row[0] = "";
					row[1] = "";
					row[2] = "";
					row[3] = "";
					row[4] = "";
					row[5] = "";
					row[6] = "";
					model.addRow(row);
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			txtpinnum.setText("");
			txtaccname.setText("");
			txtaccnum.setText("");
			txtcurrbal.setText("");
			txtdob.setText("");
			txtgender.setText("");
			txtcs.setText("");
			txtQuery.setText("");
			txtQuery.requestFocus();
		}
		if(e.getSource() == btnSearch)	{
			try {
				pinnum = JOptionPane.showInputDialog("Type Pin Number : ");
				rs = stmt.executeQuery("select * from customer_informationtb where Pin_Number='" + pinnum +"'");
				if(rs.next())	{
					displayValues();
					rs = stmt.executeQuery("select * from customer_informationtb where Pin_Number='" + pinnum +"'");
					while(model.getRowCount() > 0)	{
						model.removeRow(0);
					}
					show1();
				}
				else	{
					JOptionPane.showMessageDialog(null, "pin number not found...");
				}
			} catch (SQLException e1)	{
				e1.printStackTrace();
			}
		}
		if(e.getSource() == btnNew)	{
			txtaccname.setText("");
			txtaccnum.setText("");
			txtcurrbal.setText("");
			txtdob.setText("");
			txtgender.setText("");
			txtcs.setText("");
			txtaccnum.requestFocus();
			try	{
				rs = stmt.executeQuery("select * from customer_informationtb");
				rs.last();
				txtpinnum.setText(String.valueOf(Integer.parseInt(rs.getString("Pin_Number"))+1));
			} catch (SQLException e1)	{
				e1.printStackTrace();
			}
		}
		if(e.getSource() == btnSave)	{
			int res = JOptionPane.showConfirmDialog(null, "Save Record?", "Save", JOptionPane.YES_NO_OPTION);
			if(res == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "Saving Record Canceled...");
			}
			else {
				if((!(txtpinnum.getText().isEmpty())&&!(txtaccname.getText().isEmpty())&&!(txtaccnum.getText().isEmpty())
					&&!(txtcurrbal.getText().isEmpty())&&!(txtdob.getText().isEmpty())
					&&!(txtgender.getText().isEmpty())&&!(txtcs.getText().isEmpty()))) {
				try	{
					rs.moveToInsertRow();
					rs.updateString("Pin_Number", txtpinnum.getText());
					rs.updateString("Account_Number", txtaccnum.getText());
					rs.updateString("Account_Name", txtaccname.getText());
					rs.updateString("Current_Balance", txtcurrbal.getText());
					rs.updateString("Date_of_Birth", txtdob.getText());
					rs.updateString("Gender", txtgender.getText());
					rs.updateString("Civil_Status", txtcs.getText());
					rs.insertRow();
					JOptionPane.showMessageDialog(null, "Record saved...");
					
					while(model.getRowCount() > 0)	{
						model.removeRow(0);
					}
					rs = stmt.executeQuery("select * from customer_informationtb");
					show1();
					query = "INSERT INTO customer_informationtb (Pin_Number,Account_Number,Account_Name,Current_Balance,Date_of_Birth,Gender,Civil_Status)" + "VALUES(?,?,?,?,?,?,?)";
					PreparedStatement statement = conn.prepareStatement(query);
					statement.setString(1,txtpinnum.getText());
					statement.setString(2,txtaccnum.getText());
					statement.setString(3,txtaccname.getText());
					statement.setString(4,txtcurrbal.getText());
					statement.setString(5,txtdob.getText());
					statement.setString(6,txtgender.getText());
					statement.setString(7,txtcs.getText());
					statement.addBatch();		
					txtaccname.setText("");txtaccnum.setText("");
					txtcurrbal.setText("");txtdob.setText("");
					txtgender.setText("");txtcs.setText("");
					txtpinnum.setText("");
					
				} catch (SQLException e1)	{
					JOptionPane.showMessageDialog(null, "INVALID CUSTOMER INFORMATION!","Warning", JOptionPane.WARNING_MESSAGE);
					//e1.printStackTrace();
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "INCOMPLETE CUSTOMER INFORMATION!","Warning", JOptionPane.WARNING_MESSAGE);
			}
			}
		}
		if(e.getSource() == btnUpdate)	{
			int res = JOptionPane.showConfirmDialog(null, "Update Record?", "Update", JOptionPane.YES_NO_OPTION);
			if(res == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "User Update canceled...");
			}
			else {
			if(!((txtpinnum.getText().length()>0)&&(txtaccname.getText().length()>0)&&(txtaccnum.getText().length()>0)&&(txtcurrbal.getText().length()>0)&&(txtdob.getText().length()>0)
					&&(txtgender.getText().length()>0)&&(txtcs.getText().length()>0))) {
			JOptionPane.showMessageDialog(null, "INCOMPLETE CUSTOMER INFORMATION!","Warning", JOptionPane.WARNING_MESSAGE);
			}
			else 	{
			try	{
				query = "UPDATE customer_informationtb set Current_Balance='" + txtcurrbal.getText() + "', Account_Number='" + txtaccnum.getText() 
						+ "', Gender='" + txtgender.getText() + "', Civil_Status='" + txtcs.getText() + "',Date_of_Birth='" + txtdob.getText() + "',"
						+ " Account_Name='" + txtaccname.getText() + "'where Pin_Number=" + txtpinnum.getText();
				
				int r = stmt.executeUpdate(query);
				
				if(r > 0)	{
					JOptionPane.showMessageDialog(null, "Record updated...");
					while(model.getRowCount() > 0)	{
						model.removeRow(0);
					}
					rs = stmt.executeQuery("select * from customer_informationtb");
					show1();
				}
				else	{
					JOptionPane.showMessageDialog(null, "Error occured...");	}
			} catch (SQLException e1)	{
				JOptionPane.showMessageDialog(null, "INVALID CUSTOMER INFORMATION!","Warning", JOptionPane.WARNING_MESSAGE);
				//e1.printStackTrace();
			}
			}
					}
		}
		if(e.getSource() == btnDelete)	{
			int res = JOptionPane.showConfirmDialog(null, "Delete A Record?", "Delete", JOptionPane.YES_NO_OPTION);
			if(res == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "User Deletion Canceled...");
			}
			else {
				try	{
					pinnum = JOptionPane.showInputDialog("Type Pin Number : ");
					int r = stmt.executeUpdate( "DELETE FROM customer_informationtb where Pin_Number='" + pinnum + "'");
				
					if(r > 0)	{
						JOptionPane.showMessageDialog(null, "A user was deleted successfully!");
						rs = stmt.executeQuery("select * from customer_informationtb");
						rs.last();
						displayValues();
						while(model.getRowCount() > 0)	{
							model.removeRow(0);
						}
						rs = stmt.executeQuery("select * from customer_informationtb");
						show1();
					}
					else	{
						JOptionPane.showMessageDialog(null, "Customer Pin Number not found...");
					}	
				} catch (SQLException e1)	{
					e1.printStackTrace();
				}		
			}
		}
		if(e.getSource() == btnCancel)	{
			int res = JOptionPane.showConfirmDialog(null, "go back to user transaction?", "GROUP_01", JOptionPane.YES_NO_OPTION);
			if(res == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "switching to user transaction canceled...");
			}
			else {
				FINAL_CASE_STUDY cs = new FINAL_CASE_STUDY();
				cs.setVisible(true);
				setVisible(false);
			}
		}
		if(e.getSource() == btnQuit)	{
			int res = JOptionPane.showConfirmDialog(null, "terminate the program?", "GROUP_01", JOptionPane.YES_NO_OPTION);
			if(res == JOptionPane.NO_OPTION) {
				JOptionPane.showMessageDialog(null, "closing program canceled...");
			}
			else {
			JOptionPane.showMessageDialog(null, "                  .. GOODBYE MASTER :) ..", "Closing program...", JOptionPane.PLAIN_MESSAGE);
			System.exit(0);
			}
		}
	}
}
