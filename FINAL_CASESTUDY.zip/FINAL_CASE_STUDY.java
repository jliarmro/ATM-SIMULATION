package FINAL_CASESTUDY;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.CardLayout;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;

import CASE_STUDY.ADMINISTRATOR;

import javax.swing.JRadioButton;
import java.awt.Toolkit;

public class FINAL_CASE_STUDY extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final DecimalFormat df = new DecimalFormat("0.00");
	
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String query;
	
	private JPasswordField txtPin;
	private JPanel START, ENTERPIN, TRANSACTION, BALANCEINQUIRY, WITHDRAW, DEPOSIT;
	private JButton BTNSTART, BTNBALANCE, BTNWITHDRAW, BTNDEPOSIT;
	private JLabel lblweek,lblmonth,lblday,lblyear,lblhour, lblaccountnumber, lblaccountname;
	private JTextField txtAccountNumber, txtAccountName, txtCurrentBalance;
	private JTextField txtAmountWithdraw, txtAmountDeposit;
	private JRadioButton php10k,php5k,php15k,php20k,phpotheramount;
	private JButton btnAcceptWithdraw, btnAcceptDeposit;
	
	private JButton btnCancel, btnCancel1, btnCancel2, btnCancel3;
	private JButton btnBack, btnBack1, btnBack2;
	
	private JPanel WITHDRAW_PANEL, DEPOSIT_PANEL;
	private Panel RECEIPT_PANEL, MESSAGEPANEL;
	private JLabel lbl0, lbl1, lbl2, lbl3, lbl4, lbl5, lbldate, lblmessage, lblbalance;
	
	float WITHDRAWPRICE=0, DEPOSITPRICE=0, CURRENTBALANCE=0;
	int hour, second, minute, day, month, date, year;
	int attempts=3;
	String Pin;	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FINAL_CASE_STUDY window = new FINAL_CASE_STUDY();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}	
	/**
	 * Create the application.
	 */
	public FINAL_CASE_STUDY() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("ATM_ICON.png")));
		UIManager.put("OptionPane.background", Color.black);
		UIManager.put("Panel.background", Color.black);
		DBCONNECT();
		initialize();
		DATE_TIME();
		RECEIPT_W_D();
		BG_IMAGE();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setBounds(315, 5, 739, 370);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JPanel CARDPANEL = new JPanel();
		CARDPANEL.setBackground(Color.BLACK);
		CARDPANEL.setBounds(0, 0, 723, 331);
		getContentPane().add(CARDPANEL);
		CARDPANEL.setLayout(new CardLayout(0, 0));
		
		START = new JPanel();
		START.setBackground(Color.BLACK);
		CARDPANEL.add(START, "name_125405502332600");
		START.setLayout(null);
		
		BTNSTART = new JButton("START TRANSACTION");
		BTNSTART.setForeground(Color.WHITE);
		BTNSTART.setFont(new Font("Times New Roman", Font.BOLD, 16));
		BTNSTART.setBackground(Color.BLACK);
		BTNSTART.setBounds(246, 261, 231, 56);
		START.add(BTNSTART);
		
		JPanel MEMBER_PANEL = new JPanel();
		MEMBER_PANEL.setLayout(null);
		MEMBER_PANEL.setForeground(new Color(0, 0, 51));
		MEMBER_PANEL.setBackground(new Color(0, 0, 0, 128));
		MEMBER_PANEL.setBounds(13, 202, 202, 129);
		START.add(MEMBER_PANEL);
		
		JLabel lblGroup = new JLabel("I-AINS GROUP01");
		lblGroup.setHorizontalAlignment(SwingConstants.CENTER);
		lblGroup.setForeground(Color.WHITE);
		lblGroup.setFont(new Font("Times New Roman", Font.BOLD, 11));
		lblGroup.setBounds(17, 11, 153, 14);
		MEMBER_PANEL.add(lblGroup);
		
		JLabel name1 = new JLabel("AMANTE, RENZ");
		name1.setForeground(Color.WHITE);
		name1.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name1.setBounds(6, 27, 71, 14);
		MEMBER_PANEL.add(name1);
		
		JLabel name2 = new JLabel("ROMERO, JULIA FRANCESCA");
		name2.setForeground(Color.WHITE);
		name2.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name2.setBounds(93, 27, 104, 14);
		MEMBER_PANEL.add(name2);
		
		JLabel name3 = new JLabel("ARIAS,CRIS JAMES");
		name3.setForeground(Color.WHITE);
		name3.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name3.setBounds(6, 48, 71, 14);
		MEMBER_PANEL.add(name3);
		
		JLabel name4 = new JLabel("ARELLANO,JOHN PAUL");
		name4.setForeground(Color.WHITE);
		name4.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name4.setBounds(6, 69, 82, 14);
		MEMBER_PANEL.add(name4);
		
		JLabel name5 = new JLabel("DELA CRUZ, JOHN PAUL");
		name5.setForeground(Color.WHITE);
		name5.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name5.setBounds(93, 48, 104, 14);
		MEMBER_PANEL.add(name5);
		
		JLabel name6 = new JLabel("DELA CRUZ, ELDGIEN");
		name6.setForeground(Color.WHITE);
		name6.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name6.setBounds(93, 69, 104, 14);
		MEMBER_PANEL.add(name6);
		
		JLabel name7 = new JLabel("LAGUNAY,ALRONEAH");
		name7.setForeground(Color.WHITE);
		name7.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name7.setBounds(6, 90, 82, 14);
		MEMBER_PANEL.add(name7);
		
		JLabel name8 = new JLabel("GUEVARRA,DOMINIC");
		name8.setForeground(Color.WHITE);
		name8.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name8.setBounds(93, 90, 104, 14);
		MEMBER_PANEL.add(name8);
		
		JLabel name9 = new JLabel("FAMINI,JUSTHINE");
		name9.setForeground(Color.WHITE);
		name9.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name9.setBounds(6, 111, 71, 14);
		MEMBER_PANEL.add(name9);
		
		JLabel name10 = new JLabel("PIAOAN,PRINCESS JOY");
		name10.setForeground(Color.WHITE);
		name10.setFont(new Font("Tahoma", Font.PLAIN, 8));
		name10.setBounds(93, 111, 104, 14);
		MEMBER_PANEL.add(name10);
		
		JLabel VALIDFROM = new JLabel("Valid From:");
		VALIDFROM.setForeground(Color.WHITE);
		VALIDFROM.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		VALIDFROM.setBounds(230, 202, 68, 14);
		START.add(VALIDFROM);
		
		JLabel VALIDDATE1 = new JLabel("06/2008");
		VALIDDATE1.setForeground(Color.WHITE);
		VALIDDATE1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		VALIDDATE1.setBounds(230, 217, 49, 14);
		START.add(VALIDDATE1);
		
		JLabel VALIDTHRU = new JLabel("Valid Thru:");
		VALIDTHRU.setForeground(Color.WHITE);
		VALIDTHRU.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		VALIDTHRU.setBounds(430, 202, 74, 14);
		START.add(VALIDTHRU);
		
		JLabel VALIDATE2 = new JLabel("06/2022");
		VALIDATE2.setForeground(Color.WHITE);
		VALIDATE2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		VALIDATE2.setBounds(438, 217, 49, 14);
		START.add(VALIDATE2);
		
		JLabel CARDNAME = new JLabel("SPY \"DER\" MAN");
		CARDNAME.setHorizontalAlignment(SwingConstants.CENTER);
		CARDNAME.setForeground(Color.WHITE);
		CARDNAME.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		CARDNAME.setBounds(286, 236, 151, 14);
		START.add(CARDNAME);
		
		JLabel MABC = new JLabel("MABC");
		MABC.setForeground(Color.WHITE);
		MABC.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 40));
		MABC.setBounds(441, 29, 156, 35);
		START.add(MABC);
		
		JLabel MABC_MEAN = new JLabel("MARVEL AVENGERS BANKING CORPORATION");
		MABC_MEAN.setForeground(Color.WHITE);
		MABC_MEAN.setFont(new Font("Eras Light ITC", Font.BOLD, 13));
		MABC_MEAN.setBounds(373, 75, 281, 14);
		START.add(MABC_MEAN);
		
		JLabel ATM_NUMBER = new JLabel("4215   3803   9899   2015");
		ATM_NUMBER.setForeground(Color.WHITE);
		ATM_NUMBER.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		ATM_NUMBER.setBounds(13, 11, 188, 14);
		START.add(ATM_NUMBER);
		
		ENTERPIN = new JPanel();
		ENTERPIN.setBackground(Color.WHITE);
		CARDPANEL.add(ENTERPIN, "name_125405537287300");
		ENTERPIN.setLayout(null);
		
		MESSAGEPANEL = new Panel();
		MESSAGEPANEL.setSize(182, 44);
		lblmessage = new JLabel("");
		lblmessage.setForeground(Color.WHITE);
		lblmessage.setFont(new Font("Monospaced", Font.PLAIN, 11));
		MESSAGEPANEL.add(lblmessage);
		
		JLabel icon_1 = new JLabel("MABC");
		icon_1.setForeground(Color.BLACK);
		icon_1.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 40));
		icon_1.setBounds(68, 11, 156, 35);
		ENTERPIN.add(icon_1);
		
		JLabel icon2_1 = new JLabel("MARVEL AVENGERS BANKING CORPORATION");
		icon2_1.setForeground(Color.BLACK);
		icon2_1.setFont(new Font("Eras Light ITC", Font.BOLD, 13));
		icon2_1.setBounds(10, 57, 279, 14);
		ENTERPIN.add(icon2_1);
		
		txtPin = new JPasswordField();
		txtPin.addKeyListener(new KeyAdapter() {
		public void keyPressed(KeyEvent e) {
			 if (e.getKeyCode()==KeyEvent.VK_ENTER){
				 Pin = txtPin.getText();
				 try	{
						query = "select * from customer_informationtb where Pin_Number='" + Pin + "'";
						rs = stmt.executeQuery(query);				
						if(rs.next())	{
						lblmessage.setText("Pin Number Accepted...");
						JOptionPane.showMessageDialog(null, MESSAGEPANEL,"PIN NUMBER",JOptionPane.INFORMATION_MESSAGE);
						SETVISIBLE();
						TRANSACTION.setVisible(true);
					}
					else if(Pin.equals("0000"))	{
						lblmessage.setText("Pin Number Accepted Administrator...");
						JOptionPane.showMessageDialog(null, MESSAGEPANEL,"WELCOME ADMINISTRATOR",JOptionPane.INFORMATION_MESSAGE);
							ADMINISTRATOR ad = new ADMINISTRATOR();
							ad.setVisible(true);
							dispose();
					}
					else	{
						if(attempts != 1){
							attempts--;
							lblmessage.setText("Wrong Pin Number!...");
							JOptionPane.showMessageDialog(null, MESSAGEPANEL,"PIN NUMBER",JOptionPane.ERROR_MESSAGE);	
							txtPin.setText("");
							txtPin.requestFocus();
						} else {
							lblmessage.setText("CAPTURED CARD!...Call 1234-5678");
							JOptionPane.showMessageDialog(null, MESSAGEPANEL,"PIN NUMBER",JOptionPane.WARNING_MESSAGE);
							dispose();
						}
					}
					} catch (SQLException e1)	{
						e1.printStackTrace();
					}
			    }
			}
		});
		txtPin.setHorizontalAlignment(SwingConstants.CENTER);
		txtPin.setFont(new Font("Times New Roman", Font.PLAIN, 40));
		txtPin.setEchoChar('*');
		txtPin.setBounds(200, 123, 322, 87);
		ENTERPIN.add(txtPin);
		
		JLabel lblpin = new JLabel("Enter Pin Number:");
		lblpin.setHorizontalAlignment(SwingConstants.CENTER);
		lblpin.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblpin.setBackground(Color.WHITE);
		lblpin.setBounds(200, 78, 322, 40);
		ENTERPIN.add(lblpin);
		
		TRANSACTION = new JPanel();
		TRANSACTION.setBackground(Color.BLACK);
		CARDPANEL.add(TRANSACTION, "name_125405570153100");
		TRANSACTION.setLayout(null);
		
		BTNBALANCE = new JButton("BALANCE INQUIRY");
		BTNBALANCE.setForeground(Color.BLACK);
		BTNBALANCE.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		BTNBALANCE.setBackground(Color.LIGHT_GRAY);
		BTNBALANCE.setBounds(261, 82, 200, 45);
		TRANSACTION.add(BTNBALANCE);
		
		BTNWITHDRAW = new JButton("WITHDRAW");
		BTNWITHDRAW.setForeground(Color.BLACK);
		BTNWITHDRAW.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		BTNWITHDRAW.setBackground(Color.LIGHT_GRAY);
		BTNWITHDRAW.setBounds(261, 138, 201, 48);
		TRANSACTION.add(BTNWITHDRAW);
		
		BTNDEPOSIT = new JButton("DEPOSIT");
		BTNDEPOSIT.setForeground(Color.BLACK);
		BTNDEPOSIT.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		BTNDEPOSIT.setBackground(Color.LIGHT_GRAY);
		BTNDEPOSIT.setBounds(260, 197, 201, 45);
		TRANSACTION.add(BTNDEPOSIT);
		
		btnCancel = new JButton("CANCEL");
		btnCancel.setForeground(Color.BLACK);
		btnCancel.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnCancel.setBackground(new Color(220, 20, 60));
		btnCancel.setBounds(260, 253, 201, 45);
		TRANSACTION.add(btnCancel);
		
		BALANCEINQUIRY = new JPanel();
		BALANCEINQUIRY.setBackground(Color.WHITE);
		CARDPANEL.add(BALANCEINQUIRY, "name_125405611931300");
		BALANCEINQUIRY.setLayout(null);
		
		JLabel lblCurrentBalance = new JLabel("Current Balance: ");
		lblCurrentBalance.setForeground(Color.BLACK);
		lblCurrentBalance.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblCurrentBalance.setBounds(344, 170, 121, 15);
		BALANCEINQUIRY.add(lblCurrentBalance);
		
		JLabel lblAccountNumber = new JLabel("Account Number: ");
		lblAccountNumber.setForeground(Color.BLACK);
		lblAccountNumber.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblAccountNumber.setBounds(344, 53, 121, 15);
		BALANCEINQUIRY.add(lblAccountNumber);
		
		JLabel lblAccountName = new JLabel("Account Name: ");
		lblAccountName.setForeground(Color.BLACK);
		lblAccountName.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblAccountName.setBounds(344, 109, 121, 15);
		BALANCEINQUIRY.add(lblAccountName);
		
		txtAccountNumber = new JTextField();
		txtAccountNumber.setText((String) null);
		txtAccountNumber.setHorizontalAlignment(SwingConstants.CENTER);
		txtAccountNumber.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtAccountNumber.setEditable(false);
		txtAccountNumber.setColumns(10);
		txtAccountNumber.setBackground(Color.WHITE);
		txtAccountNumber.setBounds(475, 42, 214, 37);
		BALANCEINQUIRY.add(txtAccountNumber);
		
		txtAccountName = new JTextField();
		txtAccountName.setText((String) null);
		txtAccountName.setHorizontalAlignment(SwingConstants.CENTER);
		txtAccountName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtAccountName.setEditable(false);
		txtAccountName.setColumns(10);
		txtAccountName.setBackground(Color.WHITE);
		txtAccountName.setBounds(475, 98, 214, 37);
		BALANCEINQUIRY.add(txtAccountName);
		
		txtCurrentBalance = new JTextField();
		txtCurrentBalance.setText((String) null);
		txtCurrentBalance.setHorizontalAlignment(SwingConstants.CENTER);
		txtCurrentBalance.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtCurrentBalance.setEditable(false);
		txtCurrentBalance.setColumns(10);
		txtCurrentBalance.setBackground(Color.WHITE);
		txtCurrentBalance.setBounds(475, 159, 214, 37);
		BALANCEINQUIRY.add(txtCurrentBalance);
		
		btnBack = new JButton();
		btnBack.setText("BACK");
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnBack.setBounds(10, 288, 90, 33);
		BALANCEINQUIRY.add(btnBack);
		
		btnCancel1 = new JButton();
		btnCancel1.setText("CANCEL");
		btnCancel1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnCancel1.setBounds(624, 288, 89, 33);
		BALANCEINQUIRY.add(btnCancel1);
		
		WITHDRAW = new JPanel();
		WITHDRAW.setBackground(Color.BLACK);
		CARDPANEL.add(WITHDRAW, "name_125405650785000");
		WITHDRAW.setLayout(null);
		
		WITHDRAW_PANEL = new JPanel();
		WITHDRAW_PANEL.setLayout(null);
		WITHDRAW_PANEL.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		WITHDRAW_PANEL.setBackground(Color.BLACK);
		WITHDRAW_PANEL.setBounds(171, 40, 380, 112);
		WITHDRAW.add(WITHDRAW_PANEL);
		
		JLabel lblWithdraw = new JLabel("WITHDRAW");
		lblWithdraw.setForeground(Color.WHITE);
		lblWithdraw.setFont(new Font("Times New Roman", Font.BOLD, 34));
		lblWithdraw.setBounds(79, 0, 221, 45);
		WITHDRAW_PANEL.add(lblWithdraw);
		
		JPanel WITHDRAW_PANEL2 = new JPanel();
		WITHDRAW_PANEL2.setLayout(null);
		WITHDRAW_PANEL2.setBorder(new LineBorder(new Color(0, 0, 0)));
		WITHDRAW_PANEL2.setBackground(Color.LIGHT_GRAY);
		WITHDRAW_PANEL2.setBounds(171, 150, 380, 99);
		WITHDRAW.add(WITHDRAW_PANEL2);
		
		ButtonGroup WPRICE = new ButtonGroup();
		
		php5k = new JRadioButton("Php 5,000.00");
		php5k.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		php5k.setBackground(Color.LIGHT_GRAY);
		php5k.setBounds(252, 46, 109, 23);
		WITHDRAW_PANEL2.add(php5k);
		WPRICE.add(php5k);
		
		php10k = new JRadioButton("Php 10,000.00");
		php10k.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		php10k.setBackground(Color.LIGHT_GRAY);
		php10k.setBounds(252, 17, 109, 23);
		WITHDRAW_PANEL2.add(php10k);
		WPRICE.add(php10k);
		
		php15k = new JRadioButton("Php 15,000.00");
		php15k.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		php15k.setBackground(Color.LIGHT_GRAY);
		php15k.setBounds(21, 46, 109, 23);
		WITHDRAW_PANEL2.add(php15k);
		WPRICE.add(php15k);
		
		php20k = new JRadioButton("Php 20,000.00");
		php20k.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		php20k.setBackground(Color.LIGHT_GRAY);
		php20k.setBounds(21, 20, 109, 23);
		WITHDRAW_PANEL2.add(php20k);
		WPRICE.add(php20k);
		
		phpotheramount = new JRadioButton("Other Amount");
		phpotheramount.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		phpotheramount.setBackground(Color.LIGHT_GRAY);
		phpotheramount.setBounds(135, 72, 109, 23);
		WITHDRAW_PANEL2.add(phpotheramount);
		WPRICE.add(phpotheramount);
		
		JPanel WITHDRAW_PANEL3 = new JPanel();
		WITHDRAW_PANEL3.setLayout(null);
		WITHDRAW_PANEL3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		WITHDRAW_PANEL3.setBackground(Color.BLACK);
		WITHDRAW_PANEL3.setBounds(171, 244, 380, 61);
		WITHDRAW.add(WITHDRAW_PANEL3);
		
		txtAmountWithdraw = new JTextField();
		txtAmountWithdraw.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtAmountWithdraw.setColumns(10);
		txtAmountWithdraw.setBounds(134, 7, 111, 38);
		WITHDRAW_PANEL3.add(txtAmountWithdraw);
		
		lblaccountnumber = new JLabel();
		lblaccountname = new JLabel();
		
		btnAcceptWithdraw = new JButton("ACCEPT");
		btnAcceptWithdraw.setForeground(Color.BLACK);
		btnAcceptWithdraw.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnAcceptWithdraw.setBounds(289, 10, 81, 32);
		WITHDRAW_PANEL3.add(btnAcceptWithdraw);
		
		JLabel lblEnterAmountWithdraw = new JLabel("Enter Amount");
		lblEnterAmountWithdraw.setForeground(Color.WHITE);
		lblEnterAmountWithdraw.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblEnterAmountWithdraw.setBounds(10, 15, 77, 23);
		WITHDRAW_PANEL3.add(lblEnterAmountWithdraw);
		
		btnBack1 = new JButton();
		btnBack1.setText("BACK");
		btnBack1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnBack1.setBounds(10, 290, 90, 33);
		WITHDRAW.add(btnBack1);
		
		btnCancel2 = new JButton();
		btnCancel2.setText("CANCEL");
		btnCancel2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnCancel2.setBounds(624, 290, 89, 33);
		WITHDRAW.add(btnCancel2);
		
		DEPOSIT = new JPanel();
		DEPOSIT.setBackground(Color.BLACK);
		CARDPANEL.add(DEPOSIT, "name_125405675994600");
		DEPOSIT.setLayout(null);
		
		DEPOSIT_PANEL = new JPanel();
		DEPOSIT_PANEL.setLayout(null);
		DEPOSIT_PANEL.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		DEPOSIT_PANEL.setBackground(Color.BLACK);
		DEPOSIT_PANEL.setBounds(165, 109, 393, 128);
		DEPOSIT.add(DEPOSIT_PANEL);
		
		JLabel lblDeposit = new JLabel("DEPOSIT");
		lblDeposit.setHorizontalAlignment(SwingConstants.CENTER);
		lblDeposit.setForeground(Color.WHITE);
		lblDeposit.setFont(new Font("Times New Roman", Font.BOLD, 34));
		lblDeposit.setBounds(114, 0, 164, 39);
		DEPOSIT_PANEL.add(lblDeposit);
		
		JPanel DEPOSIT_PANEL1 = new JPanel();
		DEPOSIT_PANEL1.setLayout(null);
		DEPOSIT_PANEL1.setBorder(new LineBorder(new Color(0, 0, 0)));
		DEPOSIT_PANEL1.setBackground(Color.DARK_GRAY);
		DEPOSIT_PANEL1.setBounds(165, 232, 393, 67);
		DEPOSIT.add(DEPOSIT_PANEL1);
		
		txtAmountDeposit = new JTextField();
		txtAmountDeposit.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtAmountDeposit.setColumns(10);
		txtAmountDeposit.setBounds(114, 17, 164, 32);
		DEPOSIT_PANEL1.add(txtAmountDeposit);
		
		btnAcceptDeposit = new JButton("ACCEPT");
		btnAcceptDeposit.setForeground(Color.BLACK);
		btnAcceptDeposit.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnAcceptDeposit.setBounds(302, 17, 81, 32);
		DEPOSIT_PANEL1.add(btnAcceptDeposit);
		
		JLabel lblEnterAmountDeposit = new JLabel("Enter Amount");
		lblEnterAmountDeposit.setForeground(Color.WHITE);
		lblEnterAmountDeposit.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblEnterAmountDeposit.setBounds(10, 22, 77, 23);
		DEPOSIT_PANEL1.add(lblEnterAmountDeposit);
		
		btnBack2 = new JButton();
		btnBack2.setText("BACK");
		btnBack2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnBack2.setBounds(10, 290, 90, 33);
		DEPOSIT.add(btnBack2);
		
		btnCancel3 = new JButton();
		btnCancel3.setText("CANCEL");
		btnCancel3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnCancel3.setBounds(624, 290, 89, 33);
		DEPOSIT.add(btnCancel3);
		
		BTNSTART.addActionListener(this);
		BTNBALANCE.addActionListener(this);
		BTNWITHDRAW.addActionListener(this);
		BTNDEPOSIT.addActionListener(this);
		
		btnCancel.addActionListener(this);
		btnCancel1.addActionListener(this);
		btnCancel2.addActionListener(this);
		btnCancel3.addActionListener(this);
		
		btnBack.addActionListener(this);
		btnBack1.addActionListener(this);
		btnBack2.addActionListener(this);
		
		php5k.addActionListener(this);
		php10k.addActionListener(this);
		php15k.addActionListener(this);
		php20k.addActionListener(this);
		phpotheramount.addActionListener(this);
		
		btnAcceptWithdraw.addActionListener(this);
		btnAcceptDeposit.addActionListener(this);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == BTNSTART)	{
			SETVISIBLE();
			ENTERPIN.setVisible(true);
			txtPin.setText("");
			txtPin.requestFocus();
			attempts=3;
		}
		if(e.getSource() == BTNBALANCE)	{
			SETVISIBLE();
			BALANCEINQUIRY.setVisible(true);
				try	{
					rs = stmt.executeQuery("select Account_Number, Account_Name, Current_Balance from customer_informationtb where Pin_Number='" + Pin +"'");
					rs.next();
					txtAccountNumber.setText(String.valueOf(rs.getInt("Account_Number")));
					txtAccountName.setText(rs.getString("Account_Name"));
					txtCurrentBalance.setText("Php "+String.valueOf(df.format(rs.getFloat("Current_Balance"))));
				}catch(SQLException e1)	{
					e1.printStackTrace();
				}
		}
		if(e.getSource() == BTNWITHDRAW)	{
			SETVISIBLE();
			WITHDRAW.setVisible(true);
		}
		if(php5k.isSelected())	{
			WITHDRAWPRICE =5000;
			txtAmountWithdraw.setText(String.valueOf(df.format(WITHDRAWPRICE)));
		}
		if(php10k.isSelected())	{
			WITHDRAWPRICE =10000;
			txtAmountWithdraw.setText(String.valueOf(df.format(WITHDRAWPRICE)));
		}
		if(php15k.isSelected())	{
			WITHDRAWPRICE =15000;
			txtAmountWithdraw.setText(String.valueOf(df.format(WITHDRAWPRICE)));
		}
		if(php20k.isSelected())	{
			WITHDRAWPRICE =20000;
			txtAmountWithdraw.setText(String.valueOf(df.format(WITHDRAWPRICE)));
		}
		if(phpotheramount.isSelected())	{
			txtAmountWithdraw.setText("");
			txtAmountWithdraw.requestFocus();
		}
		if(e.getSource() == btnAcceptWithdraw)	{
			try {
				if(txtAmountWithdraw.getText().isEmpty()) {
					lblmessage.setText("Please Enter Amount....");
					JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Warning", JOptionPane.WARNING_MESSAGE);
				}
				else {
				query = "select Account_Number, Account_Name, Current_Balance from customer_informationtb where Pin_Number='" + Pin +"'";							
				CURRENTBALANCE = rs.getFloat("Current_Balance");
				
				WITHDRAWPRICE = Float.parseFloat(txtAmountWithdraw.getText());
				
				 	if(!(WITHDRAWPRICE % 100==0)) {
						MESSAGEPANEL.setSize(296,44);
						lblmessage.setSize(296,22);
						lblmessage.setText("Entered Amount should only be divible by 100!");
						JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Withdrawal", JOptionPane.ERROR_MESSAGE);
				 	}
					else if(!((WITHDRAWPRICE % 100==0 )&&(WITHDRAWPRICE <= CURRENTBALANCE))) { 
						lblmessage.setText("Insufficient Fund");
						JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Withdrawal", JOptionPane.ERROR_MESSAGE);
					}	
					else	{
						rs = stmt.executeQuery(query);
						rs.next();
						DISPLAYVALUES();						
						lblbalance.setText(String.valueOf(df.format(rs.getFloat("Current_Balance")-WITHDRAWPRICE)));
						lbl0.setText("Amount Withdrawn   :");
						lbl1.setText(lblaccountnumber.getText());		
						lbl2.setText(lblaccountname.getText());
						lbl3.setText("Php "+String.valueOf(df.format(WITHDRAWPRICE)));			
						lbl4.setText("Php "+lblbalance.getText());	
						lbl5.setText(lbldate.getText());
				
						JOptionPane.showMessageDialog(null, RECEIPT_PANEL ,"Withdrawal",JOptionPane.PLAIN_MESSAGE);
						query = "UPDATE customer_informationtb set Current_Balance='" + lblbalance.getText() +"'where Pin_Number='" + Pin +"'";
						stmt.executeUpdate(query);
						txtAmountWithdraw.setText("");
							}
					}
			}catch(Exception e1)	{
						MESSAGEPANEL.setSize(296,44);
						lblmessage.setSize(296,22);
						lblmessage.setText("Invalid Entered Amount should only be Integers...");
						JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Warning", JOptionPane.WARNING_MESSAGE);
						txtAmountWithdraw.setText("");
						txtAmountWithdraw.requestFocus();
						//e1.printStackTrace();
			}
		}
		if(e.getSource() == BTNDEPOSIT)	{
			SETVISIBLE();
			DEPOSIT.setVisible(true);
		}
		if(e.getSource() == btnAcceptDeposit)	{
			try	{
				if(txtAmountDeposit.getText().isEmpty()) {
					lblmessage.setText("Please Enter Amount...");
					JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Warning", JOptionPane.WARNING_MESSAGE);
				}
				else {
					DEPOSITPRICE = Integer.parseInt(txtAmountDeposit.getText());
					if(DEPOSITPRICE > 100) {
						rs = stmt.executeQuery("select Account_Number, Account_Name, Current_Balance from customer_informationtb where Pin_Number='" + Pin +"'");
						rs.next();
						DISPLAYVALUES();						
						lblbalance.setText(String.valueOf(df.format(rs.getFloat("Current_Balance")+DEPOSITPRICE)));
						lbl0.setText("Amount Deposited   :");
						lbl1.setText(lblaccountnumber.getText());		
						lbl2.setText(lblaccountname.getText());
						lbl3.setText("Php "+String.valueOf(df.format(DEPOSITPRICE)));			
						lbl4.setText("Php "+lblbalance.getText());	
						lbl5.setText(lbldate.getText());
						JOptionPane.showMessageDialog(null, RECEIPT_PANEL ,"Deposit",JOptionPane.PLAIN_MESSAGE);				
						query = "UPDATE customer_informationtb set Current_Balance='" + lblbalance.getText() +"'where Pin_Number='" + Pin +"'";
						stmt.executeUpdate(query);
						txtAmountDeposit.setText("");
								}
					else	{
						MESSAGEPANEL.setSize(296,44);
						lblmessage.setSize(296,22);
						lblmessage.setText("Entered Amount should only be 100 and above...");
						JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Warning", JOptionPane.WARNING_MESSAGE);
						txtAmountDeposit.setText("");
						txtAmountDeposit.requestFocus();
						}
					}
				}catch(Exception e1)	{
					MESSAGEPANEL.setSize(296,44);
					lblmessage.setSize(296,22);
					lblmessage.setText("Invalid Entered Amount should only be Integers...");
					JOptionPane.showMessageDialog(null, MESSAGEPANEL,"Warning", JOptionPane.WARNING_MESSAGE);
					txtAmountDeposit.setText("");
					txtAmountDeposit.requestFocus();
					//e1.printStackTrace();
				}
		}
		
		if((e.getSource() == btnCancel) || (e.getSource() == btnCancel1) || (e.getSource() == btnCancel2) || (e.getSource() == btnCancel3))	{
			SETVISIBLE();
			START.setVisible(true);
		}
		if((e.getSource() == btnBack)||(e.getSource() == btnBack1) || (e.getSource() == btnBack2))	{
			SETVISIBLE();
			TRANSACTION.setVisible(true);	
		}
	}
	public static void DBCONNECT()	{
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_information","root","");
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);	
		}
		catch(Exception e)	{
			e.printStackTrace();
		}
	}
	public void DISPLAYVALUES() throws SQLException	{
		lblaccountnumber.setText(String.valueOf(rs.getInt("Account_Number")));
		lblaccountname.setText(rs.getString("Account_Name"));
	}
	public void SETVISIBLE()	{
		START.setVisible(false);
		ENTERPIN.setVisible(false);
		TRANSACTION.setVisible(false);
		BALANCEINQUIRY.setVisible(false);
		WITHDRAW.setVisible(false);
		DEPOSIT.setVisible(false);
	}
	public void BG_IMAGE()	{
		JLabel BG_MAIN_FRAME = new JLabel("New label");
		BG_MAIN_FRAME.setIcon(new ImageIcon(this.getClass().getResource("BG_START.jpg")));
		BG_MAIN_FRAME.setBounds(0, 0, 723, 331);
		START.add(BG_MAIN_FRAME);
		
		JLabel BG_ENTERPIN = new JLabel("");
		BG_ENTERPIN.setIcon(new ImageIcon(this.getClass().getResource("BG_ENTERPIN.jpg")));
		BG_ENTERPIN.setBounds(0, 0, 723, 331);
		ENTERPIN.add(BG_ENTERPIN);
		
		JLabel BG_ENTERPIN_1 = new JLabel("");
		BG_ENTERPIN_1.setIcon(new ImageIcon(this.getClass().getResource("BG_ENTERPIN_1.jpg")));
		BG_ENTERPIN_1.setBounds(544, 11, 169, 309);
		ENTERPIN.add(BG_ENTERPIN_1);		

		JLabel BG_TRANSACTION1 = new JLabel("");
		BG_TRANSACTION1.setIcon(new ImageIcon(this.getClass().getResource("BG_TRANSACTION.png")));
		BG_TRANSACTION1.setBounds(-71, 124, 794, 207);
		TRANSACTION.add(BG_TRANSACTION1);
		
		JLabel BG_TRANSACTION = new JLabel("");
		BG_TRANSACTION.setIcon(new ImageIcon(this.getClass().getResource("BG_TRANSACTION_WITHDRAW_DEPOSIT.jpg")));
		BG_TRANSACTION.setBounds(0, 0, 723, 207);
		TRANSACTION.add(BG_TRANSACTION);
		
		JLabel BG_BALANCEINQUIRY = new JLabel("");
		BG_BALANCEINQUIRY.setIcon(new ImageIcon(this.getClass().getResource("BG_BALANCEINQUIRY.jpg")));
		BG_BALANCEINQUIRY.setBounds(0, 0, 723, 329);
		BALANCEINQUIRY.add(BG_BALANCEINQUIRY);
		
		JLabel BG_WITHDRAW = new JLabel("");
		BG_WITHDRAW.setIcon(new ImageIcon(this.getClass().getResource("BG_WITHDRAW_DEPOSIT.png")));
		BG_WITHDRAW.setBounds(0, 0, 380, 106);
		WITHDRAW_PANEL.add(BG_WITHDRAW);
		
		JLabel BG_WITHDRAW1 = new JLabel("");
		BG_WITHDRAW1.setIcon(new ImageIcon(this.getClass().getResource("BG_NOVA.jpg")));
		BG_WITHDRAW1.setBounds(35, 45, 166, 234);
		WITHDRAW.add(BG_WITHDRAW1);
		
		JLabel BG_WITHDRAW2 = new JLabel("");
		BG_WITHDRAW2.setIcon(new ImageIcon(this.getClass().getResource("BG_TRANSACTION_WITHDRAW_DEPOSIT.jpg")));
		BG_WITHDRAW2.setBounds(119, 0, 604, 206);
		WITHDRAW.add(BG_WITHDRAW2);
		
		JLabel BG_DEPOSIT = new JLabel("");
		BG_DEPOSIT.setIcon(new ImageIcon(this.getClass().getResource("BG_WITHDRAW_DEPOSIT.png")));
		BG_DEPOSIT.setBounds(0, 0, 393, 112);
		DEPOSIT_PANEL.add(BG_DEPOSIT);
		
		JLabel BG_DEPOSIT1 = new JLabel("");
		BG_DEPOSIT1.setIcon(new ImageIcon(this.getClass().getResource("BG_NOVA.jpg")));
		BG_DEPOSIT1.setBounds(225, 59, 288, 93);
		DEPOSIT.add(BG_DEPOSIT1);
		
		JLabel BG_DEPOSIT2 = new JLabel("");
		BG_DEPOSIT2.setIcon(new ImageIcon(this.getClass().getResource("BG_TRANSACTION_WITHDRAW_DEPOSIT.jpg")));
		BG_DEPOSIT2.setBounds(114, 0, 609, 215);
		DEPOSIT.add(BG_DEPOSIT2);
		
		JLabel BG_RECEIPT = new JLabel("");
		BG_RECEIPT.setIcon(new ImageIcon(this.getClass().getResource("BG_RECEIPT.png")));
		BG_RECEIPT.setBounds(310, 39, 72, 62);
		RECEIPT_PANEL.add(BG_RECEIPT);
	}
	public void DATE_TIME()	{
			JPanel DATE_PANEL = new JPanel();
			DATE_PANEL.setBounds(510, 202, 202, 129);
			DATE_PANEL.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.5f));
			START.add(DATE_PANEL);			
			DATE_PANEL.setLayout(null);
			
			lblweek = new JLabel();
			lblweek.setForeground(Color.WHITE);
			lblweek.setFont(new Font("Times New Roman", Font.PLAIN, 13));
			lblweek.setHorizontalAlignment(SwingConstants.CENTER);
			lblweek.setBounds(23, 5, 126, 21);
			DATE_PANEL.add(lblweek);
			
			lblmonth = new JLabel();
			lblmonth.setForeground(Color.WHITE);
			lblmonth.setFont(new Font("Times New Roman", Font.PLAIN, 13));
			lblmonth.setHorizontalAlignment(SwingConstants.CENTER);
			lblmonth.setBounds(23, 31, 126, 21);
			DATE_PANEL.add(lblmonth);
			
			lblday = new JLabel();
			lblday.setForeground(Color.WHITE);
			lblday.setFont(new Font("Times New Roman", Font.BOLD, 15));
			lblday.setHorizontalAlignment(SwingConstants.CENTER);
			lblday.setBounds(23, 57, 126, 21);
			DATE_PANEL.add(lblday);
			
			lblyear = new JLabel();
			lblyear.setForeground(Color.WHITE);
			lblyear.setFont(new Font("Times New Roman", Font.PLAIN, 13));
			lblyear.setHorizontalAlignment(SwingConstants.CENTER);
			lblyear.setBounds(23, 83, 126, 21);
			DATE_PANEL.add(lblyear);
			
			lblhour = new JLabel();
			lblhour.setForeground(Color.WHITE);
			lblhour.setFont(new Font("Times New Roman", Font.BOLD, 15));
			lblhour.setHorizontalAlignment(SwingConstants.CENTER);
			lblhour.setBounds(23, 109, 126, 21);
			DATE_PANEL.add(lblhour);
			
	Thread DATE_TIME = new Thread() {
		public void run() {
			try {
				for (;;) {
				Calendar cal = Calendar.getInstance();
				
				hour =cal.get(Calendar.HOUR_OF_DAY);
				minute =cal.get(Calendar.MINUTE);
				second =cal.get(Calendar.SECOND);
				SimpleDateFormat clock = new SimpleDateFormat("hh:mm aa");
				Date timeclock = cal.getTime();
				String timeformat = clock.format(timeclock);
				lblhour.setText(timeformat);
				
				month = cal.get(Calendar.MONTH);
				SimpleDateFormat months = new SimpleDateFormat("MMMM");
				Date mon = cal.getTime();
				String monthformat = months.format(mon);
				lblmonth.setText(monthformat);
				
				date = cal.get(Calendar.DAY_OF_MONTH);
				SimpleDateFormat days = new SimpleDateFormat("dd");
				Date daynum = cal.getTime();
				String dateformat = days.format(daynum);
				lblday.setText(dateformat);
				
				year = cal.get(Calendar.YEAR);
				SimpleDateFormat dateyear = new SimpleDateFormat("Y");
				Date yearnum = cal.getTime();
				String yearformat = dateyear.format(yearnum);
				lblyear.setText(yearformat);
				
				day = cal.get(Calendar.DAY_OF_WEEK);
				SimpleDateFormat dayname = new SimpleDateFormat("EEEE");
				Date week = cal.getTime();
				String dayformat = dayname.format(week);
				lblweek.setText(dayformat);
				
				sleep(1000);
				}
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	};
				DATE_TIME.start();	
	}
	public void RECEIPT_W_D()	{
			RECEIPT_PANEL = new Panel();
			RECEIPT_PANEL.setSize(379, 129);
			RECEIPT_PANEL.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.5f));
			RECEIPT_PANEL.setLayout(null);
			
			JLabel lblAccountNumber = new JLabel("Account Number     :");
			lblAccountNumber.setForeground(Color.WHITE);
			lblAccountNumber.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lblAccountNumber.setBounds(2, -3, 145, 22);
			RECEIPT_PANEL.add(lblAccountNumber);
			
			JLabel lblAccountName = new JLabel("Account Name       :");
			lblAccountName.setForeground(Color.WHITE);
			lblAccountName.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lblAccountName.setBounds(2, 22, 145, 22);
			RECEIPT_PANEL.add(lblAccountName);
			
			lbl0 = new JLabel();
			lbl0.setForeground(Color.WHITE);
			lbl0.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lbl0.setBounds(2, 47, 145, 22);
			RECEIPT_PANEL.add(lbl0);
			
			JLabel lblAccountBalance = new JLabel("Account Balance    :");
			lblAccountBalance.setForeground(Color.WHITE);
			lblAccountBalance.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lblAccountBalance.setBounds(2, 72, 145, 22);
			RECEIPT_PANEL.add(lblAccountBalance);
			
			JLabel lblDate = new JLabel("Date               :");
			lblDate.setForeground(Color.WHITE);
			lblDate.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lblDate.setBounds(2, 97, 145, 22);
			RECEIPT_PANEL.add(lblDate);
			
			lbl1 = new JLabel();
			lbl1.setForeground(Color.WHITE);
			lbl1.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lbl1.setBounds(164, -3, 218, 22);
			RECEIPT_PANEL.add(lbl1);
			
			lbl2 = new JLabel();
			lbl2.setForeground(Color.WHITE);
			lbl2.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lbl2.setBounds(164, 22, 218, 22);
			RECEIPT_PANEL.add(lbl2);
			
			lbl3 = new JLabel();
			lbl3.setForeground(Color.WHITE);
			lbl3.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lbl3.setBounds(164, 47, 218, 22);
			RECEIPT_PANEL.add(lbl3);
			lblbalance = new JLabel("BALANCE");
			lbl4 = new JLabel();
			lbl4.setForeground(Color.WHITE);
			lbl4.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lbl4.setBounds(164, 72, 218, 22);
			RECEIPT_PANEL.add(lbl4);
			
			Date date = new Date();
			SimpleDateFormat DateFor = new SimpleDateFormat("MMMM dd, yyyy / hh:mm aa");
			String stringDate5 = DateFor.format(date);
			
			lbldate = new JLabel("date");
			lbldate.setText(stringDate5);
			
			lbl5 = new JLabel(lbldate.getText());
			lbl5.setForeground(Color.WHITE);
			lbl5.setFont(new Font("Monospaced", Font.PLAIN, 11));
			lbl5.setBounds(164, 97, 218, 22);
			RECEIPT_PANEL.add(lbl5);
			
			JLabel lblNewLabel = new JLabel("----------------------------------------------------------------");
			lblNewLabel.setForeground(Color.WHITE);
			lblNewLabel.setBounds(59, 118, 261, 8);
			RECEIPT_PANEL.add(lblNewLabel);
	}
}
